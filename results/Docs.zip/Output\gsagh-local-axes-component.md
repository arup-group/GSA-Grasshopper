# Local Axes
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided "as-is" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

|<img width=150/> Icon |
| ----------- |
|![Local Axes](./images/LocalAxes.png) |

## Description

Get the local axes from a 1D Element or Member

### Input parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![GenericParam](./images/GenericParam.png) |`Generic` |**Element/Member 1D** |Element1D or Member1D to get local axes for. |

### Output parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![VectorParam](./images/VectorParam.png) |`Vector` |**Local X** |Element1D or Member1D's local X-axis |
|![VectorParam](./images/VectorParam.png) |`Vector` |**Local Y** |Element1D or Member1D's local X-axis |
|![VectorParam](./images/VectorParam.png) |`Vector` |**Local Z** |Element1D or Member1D's local X-axis |


