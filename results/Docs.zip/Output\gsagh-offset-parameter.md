# Offset
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided "as-is" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

|<img width=150/> Icon |
| ----------- |
|![OffsetParam](./images/OffsetParam.png) |

## Description

An Offset will locally move the [Section](gsagh-section-parameter.html) or [Property 2D](gsagh-property-2d-parameter.html) away from the centre of the local axis in [Element 1D](gsagh-element-1d-parameter.html), [Member 1D](gsagh-member-1d-parameter.html), [Element 2D](gsagh-element-2d-parameter.html), or [Member 2D](gsagh-member-2d-parameter.html).

## Properties

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` |**X1** |`X1` - Start axial offset |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` |**X2** |`X2` - End axial offset |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` |**Y** |`Y` Offset |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` |**Z** |`Z` Offset |

_Note: the above properties can be retrieved using the [Edit Offset](gsagh-edit-offset-component.html) component_
