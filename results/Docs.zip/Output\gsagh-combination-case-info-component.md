# Combination Case Info
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided "as-is" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

|<img width=150/> Icon |
| ----------- |
|![Combination Case Info](./images/CombinationCaseInfo.png) |

## Description

Get information of a GSA Combination Case

### Input parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![CombinationCaseParam](./images/CombinationCaseParam.png) |[Combination Case](gsagh-combination-case-parameter.html) |**Combination Case** |Combination Case parameter |

### Output parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![IntegerParam](./images/IntegerParam.png) |`Integer` |**ID** |Combination Case number |
|![TextParam](./images/TextParam.png) |`Text` |**Name** |Combination Case Name |
|![TextParam](./images/TextParam.png) |`Text` |**Description** |The description should take the form: 1.5A1 + 0.4A3.<br />Use 'or' for enveloping cases eg (1 or -1.4)A1,<br />'to' for enveloping a range of cases eg (C1 to C3) |


