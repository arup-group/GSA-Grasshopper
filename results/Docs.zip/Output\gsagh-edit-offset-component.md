# Edit Offset
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided "as-is" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

|<img width=150/> Icon |
| ----------- |
|![Edit Offset](./images/EditOffset.png) |

## Description

Modify GSA Offset or just get information about existing

### Input parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![OffsetParam](./images/OffsetParam.png) |[Offset](gsagh-offset-parameter.html) |**Offset** |Offset to get or set information for. Leave blank to create a new Offset |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` |**X1 [cm]** |`X1` - Start axial offset |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` |**X2 [cm]** |`X2` - End axial offset |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` |**Y [cm]** |`Y` Offset |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` |**Z [cm]** |`Z` Offset |

### Output parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![OffsetParam](./images/OffsetParam.png) |[Offset](gsagh-offset-parameter.html) |**Offset** |GSA Offset with applied changes. |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` |**X1** |`X1` - Start axial offset |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` |**X2** |`X2` - End axial offset |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` |**Y** |`Y` Offset |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` |**Z** |`Z` Offset |


