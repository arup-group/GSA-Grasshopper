# Section Modifier
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided "as-is" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

|<img width=150/> Icon |
| ----------- |
|![SectionModifierParam](./images/SectionModifierParam.png) |

## Description

A Section Modifier is part of a [Section](gsagh-section-parameter.html) and can be used to modify property's analytical properties without changing the `Profile` or [Material](gsagh-material-parameter.html). By default the Section Modifier is unmodified. Refer to [Section Modifiers](/references/hidr-data-sect-lib.html#modifiers) to read more.



## Properties

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![SectionModifierParam](./images/SectionModifierParam.png) |[Section Modifier](gsagh-section-modifier-parameter.html) |**Section Modifier** |GSA Section Modifier with applied changes. |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Area ` |**Area Modifier** |Effective Area |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Area Moment Of Inertia ` |**I11 Modifier** |Effective Iyy/Iuu |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Area Moment Of Inertia ` |**I22 Modifier** |Effective Izz/Ivv |
|![GenericParam](./images/GenericParam.png) |`Generic` |**J Modifier** |Effective J |
|![GenericParam](./images/GenericParam.png) |`Generic` |**K11 Modifier** |Effective Kyy/Kuu |
|![GenericParam](./images/GenericParam.png) |`Generic` |**K22 Modifier** |Effective Kzz/Kvv |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Volume Per Length ` |**Volume Modifier** |Effective Volume/Length |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Linear Density ` |**Additional Mass** |Additional mass per unit length |
|![BooleanParam](./images/BooleanParam.png) |`Boolean` |**Principal Bending Axis** |If 'true' GSA will use Principal (u,v) Axis for Bending. If false, Local (y,z) Axis will be used |
|![BooleanParam](./images/BooleanParam.png) |`Boolean` |**Reference Point Centroid** |If 'true' GSA will use the Centroid as Analysis Reference Point. If false, the specified point will be used |
|![GenericParam](./images/GenericParam.png) |`Generic` |**Stress Option Type** |the Stress Option Type:<br />0: No Calculation<br />1: Use Modified section properties<br />2: Use Unmodified section properties |

_Note: the above properties can be retrieved using the [Get Section Modifier](gsagh-get-section-modifier-component.html) component_
