# Parameters
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided \"as-is\" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

The GSA Grasshopper plugin introduces a new set of custom Grasshopper parameters. Parameters are what is passed from one component's output to another component's input.
![Parameters](https://developer.rhino3d.com/api/grasshopper/media/ParameterKinds.png)

## Custom GSA Parameters

## Model

|<img width=20/>   |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- |
|![GridLineParam](./images/GridLineParam.png) |[Grid Line](gsagh-grid-line-parameter.html) |Grid Line parameter |
|![ListParam](./images/ListParam.png) |[List](gsagh-list-parameter.html) |Entity List parameter |
|![ModelParam](./images/ModelParam.png) |[Model](gsagh-model-parameter.html) |Model parameter |

## Properties

|<img width=20/>   |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- |
|![Bool6Param](./images/Bool6Param.png) |[Bool6](gsagh-bool6-parameter.html) |Bool6 containing six booleans representing a release or restriant. parameter |
|![MaterialParam](./images/MaterialParam.png) |[Material](gsagh-material-parameter.html) |Material parameter |
|![OffsetParam](./images/OffsetParam.png) |[Offset](gsagh-offset-parameter.html) |Offset parameter |
|![Property2dModifierParam](./images/Property2dModifierParam.png) |[Property 2D Modifier](gsagh-property-2d-modifier-parameter.html) |Property 2D Modifier parameter |
|![Property2dParam](./images/Property2dParam.png) |[Property 2D](gsagh-property-2d-parameter.html) |2D Property (Area) parameter |
|![Property3dParam](./images/Property3dParam.png) |[Property 3D](gsagh-property-3d-parameter.html) |3D Property (Volumetric) parameter |
|![SectionModifierParam](./images/SectionModifierParam.png) |[Section Modifier](gsagh-section-modifier-parameter.html) |Section Modifier parameter |
|![SectionParam](./images/SectionParam.png) |[Section](gsagh-section-parameter.html) |Section Property (Beam) parameter |

## Geometry

|<img width=20/>   |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- |
|![BucklingFactorsParam](./images/BucklingFactorsParam.png) |[Buckling Factors](gsagh-buckling-factors-parameter.html) |Equivalent uniform moment factor for LTB for 1D Member parameter |
|![Element1dParam](./images/Element1dParam.png) |[Element 1D](gsagh-element-1d-parameter.html) |1D Element parameter |
|![Element2dParam](./images/Element2dParam.png) |[Element 2D](gsagh-element-2d-parameter.html) |2D Element(s) parameter |
|![Element3dParam](./images/Element3dParam.png) |[Element 3D](gsagh-element-3d-parameter.html) |3D Element(s) parameter |
|![Member1dParam](./images/Member1dParam.png) |[Member 1D](gsagh-member-1d-parameter.html) |1D Member parameter |
|![Member2dParam](./images/Member2dParam.png) |[Member 2D](gsagh-member-2d-parameter.html) |2D Member parameter |
|![Member3dParam](./images/Member3dParam.png) |[Member 3D](gsagh-member-3d-parameter.html) |3D Member parameter |
|![NodeParam](./images/NodeParam.png) |[Node](gsagh-node-parameter.html) |Node parameter |

## Loads

|<img width=20/>   |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- |
|![GridPlaneSurfaceParam](./images/GridPlaneSurfaceParam.png) |[Grid Plane Surface](gsagh-grid-plane-surface-parameter.html) |Grid Plane Surface parameter |
|![LoadCaseParam](./images/LoadCaseParam.png) |[Load Case](gsagh-load-case-parameter.html) |Load Case parameter |
|![LoadParam](./images/LoadParam.png) |[Load](gsagh-load-parameter.html) |Load parameter |

## Analysis

|<img width=20/>   |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- |
|![AnalysisCaseParam](./images/AnalysisCaseParam.png) |[Analysis Case](gsagh-analysis-case-parameter.html) |Analysis Case parameter |
|![AnalysisTaskParam](./images/AnalysisTaskParam.png) |[Analysis Task](gsagh-analysis-task-parameter.html) |Analysis Task parameter |
|![CombinationCaseParam](./images/CombinationCaseParam.png) |[Combination Case](gsagh-combination-case-parameter.html) |Combination Case parameter |

## Results

|<img width=20/>   |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- |
|![ResultParam](./images/ResultParam.png) |[Result](gsagh-result-parameter.html) |Result parameter |


