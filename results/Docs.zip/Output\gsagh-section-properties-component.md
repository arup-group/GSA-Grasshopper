# Section Properties
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided "as-is" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

|<img width=150/> Icon |
| ----------- |
|![Section Properties](./images/SectionProperties.png) |

## Description

Get GSA Section Properties

### Input parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![SectionParam](./images/SectionParam.png) |[Section](gsagh-section-parameter.html) |**Section** |Section Property (Beam) to get a bit more info out of. |

### Output parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Area ` |**Area [cm²]** |Section Area |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Area Moment Of Inertia ` |**Moment of Inertia y-y [cm⁴]** |Section Moment of Intertia around local y-y axis |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Area Moment Of Inertia ` |**Moment of Inertia z-z [cm⁴]** |Section Moment of Intertia around local z-z axis |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Area Moment Of Inertia ` |**Moment of Inertia y-z [cm⁴]** |Section Moment of Intertia around local y-z axis |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Area Moment Of Inertia ` |**Moment of Inertia u-u [cm⁴]** |Section Moment of Intertia around principal u-u axis |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Area Moment Of Inertia ` |**Moment of Inertia v-v [cm⁴]** |Section Moment of Intertia around principal v-v axis |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Angle ` |**Angle [°]** |Angle between local and principal axis |
|![GenericParam](./images/GenericParam.png) |`Generic` |**Shear Area Factor y-y** |Section Shear Area Factor around local y-y axis |
|![GenericParam](./images/GenericParam.png) |`Generic` |**Shear Area Factor z-z** |Section Shear Area Factor around local z-z axis |
|![GenericParam](./images/GenericParam.png) |`Generic` |**Shear Area Factor u-u** |Section Shear Area Factor around local u-u axis |
|![GenericParam](./images/GenericParam.png) |`Generic` |**Shear Area Factor v-v** |Section Shear Area Factor around local v-v axis |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Area Moment Of Inertia ` |**Torsion Constant J [cm⁴]** |Section Torsion constant J |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Section Modulus ` |**Torsion Constant C [cm³]** |Section Torsion constant C |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Section Modulus ` |**Section Modulus in y [cm³]** |Section Modulus in y-direction |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Section Modulus ` |**Section Modulus in z [cm³]** |Section Modulus in z-direction |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Section Modulus ` |**Plastic Modulus in y [cm³]** |Plastic Section Modulus in y-direction |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Section Modulus ` |**Plastic Modulus in z [cm³]** |Plastic Section Modulus in z-direction |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` |**Elastic Centroid in y [cm]** |Elastic Centroid in y-direction |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` |**Elastic Centroid in z [cm]** |Elastic Centroid in z-direction |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` |**Radius of Gyration in y [cm]** |Radius of Gyration in y-direction |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` |**Radius of Gyration in z [cm]** |Radius of Gyration in z-direction |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Surface Area / Unit Length ` |**Surface Area / Unit Length [cm²/cm]** |Section Surface Area per Unit Length |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Volume / Unit Length ` |**Volume / Unit Length [cm³/cm]** |Section Volume per Unit Length |


