# Node Displacements
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided "as-is" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

|<img width=150/> Icon |
| ----------- |
|![Node Displacements](./images/NodeDisplacements.png) |

## Description

Node Translation and Rotation result values

_Note: This is a dropdown component and input/output may vary depending on the selected dropdown_

### Input parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![ResultParam](./images/ResultParam.png) |[Result](gsagh-result-parameter.html) _List_ |**Result** |Result |
|![ListParam](./images/ListParam.png) |[List](gsagh-list-parameter.html) |**Node filter list** |Filter the Nodes by list. (by default 'all')<br />Node list should take the form:<br /> 1 11 to 72 step 2 not (XY3 31 to 45)<br />Refer to help file for definition of lists and full vocabulary. |

### Output parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` _Tree_ |**Translations X [mm]** |Translations in X-direction in Global Axis. |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` _Tree_ |**Translations Y [mm]** |Translations in Y-direction in Global Axis |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` _Tree_ |**Translations Z [mm]** |Translations in Z-direction in Global Axis |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` _Tree_ |**Translations XYZ [mm]** |Combined XYZ Translations in Global Axis |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Angle ` _Tree_ |**Rotations XX [rad]** |Rotations around X-axis in Global Axis |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Angle ` _Tree_ |**Rotations YY [rad]** |Rotations around Y-axis in Global Axis |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Angle ` _Tree_ |**Rotations ZZ [rad]** |Rotations around Z-axis in Global Axis |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Angle ` _Tree_ |**Rotations XYZ [rad]** |Combined XXYYZZ Rotations in Global Axis |
|![TextParam](./images/TextParam.png) |`Text` _Tree_ |**Nodes IDs** |Node IDs for each result value |


