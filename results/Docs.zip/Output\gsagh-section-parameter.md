# Section
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided "as-is" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

|<img width=150/> Icon |
| ----------- |
|![SectionParam](./images/SectionParam.png) |

## Description

A Section is used by [Element 1D](gsagh-element-1d-parameter.html) and [Member 1D](gsagh-member-1d-parameter.html) and generally contains information about it's `Profile` and [Material](gsagh-material-parameter.html). Use the [Create Profile](gsagh-create-profile-component.html) component to create Catalogue and custom profiles.

Refer to [Sections](/references/hidr-data-sect-lib.html) to read more.



## Properties

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![IntegerParam](./images/IntegerParam.png) |`Integer` |**Section Number** |Original Section number (ID) if the Section ever belonged to a GSA Model |
|![TextParam](./images/TextParam.png) |`Text` |**Section Profile** |Profile description |
|![MaterialParam](./images/MaterialParam.png) |[Material](gsagh-material-parameter.html) |**Material** |Material |
|![GenericParam](./images/GenericParam.png) |`Generic` |**Basic Offset** |Basic Offset |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` |**Add. Offset Y** |Additional Offset Y |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` |**Add. Offset Z** |Additional Offset Z |
|![SectionModifierParam](./images/SectionModifierParam.png) |[Section Modifier](gsagh-section-modifier-parameter.html) |**Section Modifier** |Section Modifier |
|![IntegerParam](./images/IntegerParam.png) |`Integer` |**Section Pool** |Section pool |
|![TextParam](./images/TextParam.png) |`Text` |**Section Name** |Section name |
|![ColourParam](./images/ColourParam.png) |`Colour` |**Section Colour** |Section colour |

_Note: the above properties can be retrieved using the [Edit Section](gsagh-edit-section-component.html) component_
