# Result
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided "as-is" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

|<img width=150/> Icon |
| ----------- |
|![ResultParam](./images/ResultParam.png) |

## Description

A Result is used to select Cases from an analysed [Model](gsagh-model-parameter.html) and extract the values for post-processing or visualisation.

All result values from the [.NET API](/references/dotnet-api/introduction.html) has been wrapped in [Unit Number](/references/gsagh/gsagh-unitnumber-parameter.html) and can be converted into different measures on the fly. The Result parameter caches the result values

The following result types can be extracted if they are present in the model: <list type="bullet[Node Results](/references/dotnet-api/result-classes.html#noderesult): `Displacement` and `Reaction`</description></item><item><description>[1D Element Results](/references/dotnet-api/result-classes.html#element1dresult): `Displacement`, `Force` and `StrainEnergyDensity`</description></item><item><description>[2D Element Results](/references/dotnet-api/result-classes.html#element2dresult): `Displacement`, `Force`, `Moment`, `Shear` and `Stress`</description></item><item><description>[3D Element Results](/references/dotnet-api/result-classes.html#element3dresult): `Displacement` and `Stress`</description></item><item><description>[Global Results](/references/dotnet-api/result-classes.html#globalresult)</description>: `Frequency`, `LoadFactor`, `ModalGeometricStiffness`, `ModalMass`, `ModalStiffness`, `TotalLoad`, `TotalReaction`, `Mode`, `EffectiveInertia` and `EffectiveMass`</item></list>




