# Beam Forces and Moments
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided "as-is" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

|<img width=150/> Icon |
| ----------- |
|![Beam Forces and Moments](./images/BeamForcesandMoments.png) |

## Description

Element1D Force and Moment result values

_Note: This is a dropdown component and input/output may vary depending on the selected dropdown_

### Input parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![ResultParam](./images/ResultParam.png) |[Result](gsagh-result-parameter.html) _List_ |**Result** |Result |
|![ListParam](./images/ListParam.png) |[List](gsagh-list-parameter.html) |**Element filter list** |Filter the Elements by list. (by default 'all')<br />Element list should take the form:<br /> 1 11 to 20 step 2 P1 not (G1 to G6 step 3) P11 not (PA PB1 PS2 PM3 PA4 M1)<br />Refer to help file for definition of lists and full vocabulary. |
|![IntegerParam](./images/IntegerParam.png) |`Integer` |**Intermediate Points** |Number of intermediate equidistant points (default 3) |



_Output note: DataTree organised as { `CaseID` ; `Permutation` ; `ElementID` } fx. `{1;2;3}` is Case 1, Permutation 2, Element 3, where each branch contains a list of results per element position._
### Output parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Force ` _Tree_ |**Force X [kN]** |Element Axial Forces in Local Element X-direction.<br />+ve axial forces are tensile |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Force ` _Tree_ |**Force Y [kN]** |Element Shear Forces in Local Element Y-direction.<br />+ve axial forces are tensile |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Force ` _Tree_ |**Force Z [kN]** |Element Shear Forces in Local Element Z-direction.<br />+ve axial forces are tensile |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Force ` _Tree_ |**Force XYZ [kN]** |Total YZ Element Shear Forces. |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Moment ` _Tree_ |**Moment XX [kN·m]** |Element Torsional Moments around Local Element X-axis.<br />Moments follow the right hand grip rule |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Moment ` _Tree_ |**Moment YY [kN·m]** |Element Bending Moments around Local Element Y-axis.<br />Moments follow the right hand grip rule |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Moment ` _Tree_ |**Moment ZZ [kN·m]** |Element Bending Moments around Local Element Z-axis.<br />Moments follow the right hand grip rule |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Moment ` _Tree_ |**Moment XXYYZZ [kN·m]** |Total YYZZ Element Bending Moments. |


