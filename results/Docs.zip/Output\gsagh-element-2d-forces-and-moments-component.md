# Element 2D Forces and Moments
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided "as-is" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

|<img width=150/> Icon |
| ----------- |
|![Element 2D Forces and Moments](./images/Element2DForcesandMoments.png) |

## Description

2D Projected Force and Moment result values

_Note: This is a dropdown component and input/output may vary depending on the selected dropdown_

### Input parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![ResultParam](./images/ResultParam.png) |[Result](gsagh-result-parameter.html) _List_ |**Result** |Result |
|![ListParam](./images/ListParam.png) |[List](gsagh-list-parameter.html) |**Element filter list** |Filter the Elements by list. (by default 'all')<br />Element list should take the form:<br /> 1 11 to 20 step 2 P1 not (G1 to G6 step 3) P11 not (PA PB1 PS2 PM3 PA4 M1)<br />Refer to help file for definition of lists and full vocabulary. |

### Output parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Force Per Length ` _Tree_ |**Force X [kN/m]** |Element in-plane Forces in Local X-direction.<br />+ve in plane force resultant: tensile<br />DataTree organised as { CaseID ; Permutation ; ElementID } <br />fx. {1;2;3} is Case 1, Permutation 2, Element 3, where each <br />branch contains a list of results in the following order: <br />Vertex(1), Vertex(2), ..., Vertex(i), Centre<br />Element results are NOT averaged at nodes |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Force Per Length ` _Tree_ |**Force Y [kN/m]** |Element in-plane Forces in Local Y-direction.<br />+ve in plane force resultant: tensile<br />DataTree organised as { CaseID ; Permutation ; ElementID } <br />fx. {1;2;3} is Case 1, Permutation 2, Element 3, where each <br />branch contains a list of results in the following order: <br />Vertex(1), Vertex(2), ..., Vertex(i), Centre<br />Element results are NOT averaged at nodes |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Force Per Length ` _Tree_ |**Force Z [kN/m]** |Element in-plane Forces in Local XY-direction.<br />+ve in plane force resultant: tensile<br />DataTree organised as { CaseID ; Permutation ; ElementID } <br />fx. {1;2;3} is Case 1, Permutation 2, Element 3, where each <br />branch contains a list of results in the following order: <br />Vertex(1), Vertex(2), ..., Vertex(i), Centre<br />Element results are NOT averaged at nodes |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Force Per Length ` _Tree_ |**Shear X [kN/m]** |Element through thickness Shears in Local XZ-plane.<br />DataTree organised as { CaseID ; Permutation ; ElementID } <br />fx. {1;2;3} is Case 1, Permutation 2, Element 3, where each <br />branch contains a list of results in the following order: <br />Vertex(1), Vertex(2), ..., Vertex(i), Centre<br />Element results are NOT averaged at nodes |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Force Per Length ` _Tree_ |**Shear Y [kN/m]** |Element through thickness Shears in Local YZ-plane.<br />DataTree organised as { CaseID ; Permutation ; ElementID } <br />fx. {1;2;3} is Case 1, Permutation 2, Element 3, where each <br />branch contains a list of results in the following order: <br />Vertex(1), Vertex(2), ..., Vertex(i), Centre<br />Element results are NOT averaged at nodes |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Force ` _Tree_ |**Moment X [kN]** |Element Moments around Local Element X-axis.<br />+ve moments correspond to +ve stress on the top (eg. Mx +ve if top Sxx +ve)<br />DataTree organised as { CaseID ; Permutation ; ElementID } <br />fx. {1;2;3} is Case 1, Permutation 2, Element 3, where each <br />branch contains a list of results in the following order: <br />Vertex(1), Vertex(2), ..., Vertex(i), Centre<br />Element results are NOT averaged at nodes |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Force ` _Tree_ |**Moment Y [kN]** |Element Moments around Local Element Y-axis.<br />+ve moments correspond to +ve stress on the top (eg. Mx +ve if top Sxx +ve)<br />DataTree organised as { CaseID ; Permutation ; ElementID } <br />fx. {1;2;3} is Case 1, Permutation 2, Element 3, where each <br />branch contains a list of results in the following order: <br />Vertex(1), Vertex(2), ..., Vertex(i), Centre<br />Element results are NOT averaged at nodes |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Force ` _Tree_ |**Moment XY [kN]** |Element Moments around Local Element XY-axis.<br />+ve moments correspond to +ve stress on the top (eg. Mx +ve if top Sxx +ve)<br />DataTree organised as { CaseID ; Permutation ; ElementID } <br />fx. {1;2;3} is Case 1, Permutation 2, Element 3, where each <br />branch contains a list of results in the following order: <br />Vertex(1), Vertex(2), ..., Vertex(i), Centre<br />Element results are NOT averaged at nodes |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Force ` _Tree_ |**Wood-Armer X [kN]** |Element Wood-Armer Moments (Mx + sgn(Mx)·Mxy) around Local Element X-axis.<br />+ve moments correspond to +ve stress on the top (eg. Mx +ve if top Sxx +ve)<br />DataTree organised as { CaseID ; Permutation ; ElementID } <br />fx. {1;2;3} is Case 1, Permutation 2, Element 3, where each <br />branch contains a list of results in the following order: <br />Vertex(1), Vertex(2), ..., Vertex(i), Centre<br />Element results are NOT averaged at nodes |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Force ` _Tree_ |**Wood-Armer Y [kN]** |Element Wood-Armer Moments (My + sgn(My)·Mxy) around Local Element Y-axis.<br />+ve moments correspond to +ve stress on the top (eg. Mx +ve if top Sxx +ve)<br />DataTree organised as { CaseID ; Permutation ; ElementID } <br />fx. {1;2;3} is Case 1, Permutation 2, Element 3, where each <br />branch contains a list of results in the following order: <br />Vertex(1), Vertex(2), ..., Vertex(i), Centre<br />Element results are NOT averaged at nodes |


