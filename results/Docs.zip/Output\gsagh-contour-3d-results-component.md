# Contour 3D Results
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided "as-is" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

|<img width=150/> Icon |
| ----------- |
|![Contour 3D Results](./images/Contour3DResults.png) |

## Description

Displays GSA 3D Element Results as Contour

_Note: This is a dropdown component and input/output may vary depending on the selected dropdown_

### Input parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![ResultParam](./images/ResultParam.png) |[Result](gsagh-result-parameter.html) |**Result** |Result |
|![ListParam](./images/ListParam.png) |[List](gsagh-list-parameter.html) |**Element filter list** |Filter the Elements by list. (by default 'all')<br />Element list should take the form:<br /> 1 11 to 20 step 2 P1 not (G1 to G6 step 3) P11 not (PA PB1 PS2 PM3 PA4 M1)<br />Refer to help file for definition of lists and full vocabulary. |
|![ColourParam](./images/ColourParam.png) |`Colour` _List_ |**Colour** |Optional list of colours to override default colours<br />A new gradient will be created from the input list of colours |
|![IntervalParam](./images/IntervalParam.png) |`Interval` |**Min/Max Domain** |Opitonal Domain for custom Min to Max contour colours |

### Output parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![GenericParam](./images/GenericParam.png) |`Generic` |**Ngon Mesh** |Ngon Mesh with coloured result values |
|![GenericParam](./images/GenericParam.png) |`Generic` _List_ |**Colours** |Legend Colours |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` _List_ |**Values [mm]** |Legend Values |


