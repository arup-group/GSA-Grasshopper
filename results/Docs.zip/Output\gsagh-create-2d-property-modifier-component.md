# Create 2D Property Modifier
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided "as-is" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

|<img width=150/> Icon |
| ----------- |
|![Create 2D Property Modifier](./images/Create2DPropertyModifier.png) |

## Description

Create GSA 2D Property Modifier

_Note: This is a dropdown component and input/output may vary depending on the selected dropdown_

### Input parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![GenericParam](./images/GenericParam.png) |`Generic` |**In-plane Modifier** |[Optional] Modify the effective in-plane stiffness BY this decimal fraction value (Default = 1.0 -> 100%) |
|![GenericParam](./images/GenericParam.png) |`Generic` |**Bending Modifier** |[Optional] Modify the effective bending stiffness BY this decimal fraction value (Default = 1.0 -> 100%) |
|![GenericParam](./images/GenericParam.png) |`Generic` |**Shear Modifier** |[Optional] Modify the effective shear stiffness BY thisdecimal fraction value (Default = 1.0 -> 100%) |
|![GenericParam](./images/GenericParam.png) |`Generic` |**Volume Modifier** |[Optional] Modify the effective volume BY this decimal fraction value (Default = 1.0 -> 100%) |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Area Density ` |**Additional Mass [kg/m²]** |[Optional] Additional mass per unit length (Default = 0 -> no additional mass) |

### Output parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![Property2dModifierParam](./images/Property2dModifierParam.png) |[Property 2D Modifier](gsagh-property-2d-modifier-parameter.html) |**Property 2D Modifier** |GSA Property 2D Modifier parameter |


