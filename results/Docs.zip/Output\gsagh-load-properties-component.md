# Load Properties
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided "as-is" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

|<img width=150/> Icon |
| ----------- |
|![Load Properties](./images/LoadProperties.png) |

## Description

Get properties of a GSA Load

_Note: This is a dropdown component and input/output may vary depending on the selected dropdown_

### Input parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![LoadParam](./images/LoadParam.png) |[Load](gsagh-load-parameter.html) |**Load** |Load to get some info out of. |

### Output parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![LoadCaseParam](./images/LoadCaseParam.png) |[Load Case](gsagh-load-case-parameter.html) |**Load Case** |GSA Load Case parameter |
|![TextParam](./images/TextParam.png) |`Text` |**Name** |Load name |
|![GenericParam](./images/GenericParam.png) |`Generic` |**Definition** |Node, Element or Member list that load is applied to or Grid point / polygon definition |
|![IntegerParam](./images/IntegerParam.png) |`Integer` |**Axis** |Axis Property (0 : Global // -1 : Local |
|![TextParam](./images/TextParam.png) |`Text` |**Direction** |Load direction |
|![BooleanParam](./images/BooleanParam.png) |`Boolean` |**Projected** |Projected |
|![UnitNumber](./images/UnitParam.png) |Unit Number |**Load Value or Factor X** |Value at Start, Point 1 or Factor X |
|![UnitNumber](./images/UnitParam.png) |Unit Number |**Load Value or Factor Y** |Value at End, Point 2 or Factor Y |
|![UnitNumber](./images/UnitParam.png) |Unit Number |**Load Value or Factor Z** |Value at Point 3 or Factor Z |
|![UnitNumber](./images/UnitParam.png) |Unit Number |**Load Value** |Value at Point 4 |
|![GridPlaneSurfaceParam](./images/GridPlaneSurfaceParam.png) |[Grid Plane Surface](gsagh-grid-plane-surface-parameter.html) |**Grid Plane Surface** |GSA Grid Plane Surface parameter |


