# Properties components 
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

#### Primary

|<img width=20/>   |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- |
|![Create Custom Material](./images/CreateCustomMaterial.png) |[Create Custom Material](gsagh-create-custom-material-component.html) |Create a Custom Analysis Material |
|![Create Material](./images/CreateMaterial.png) |[Create Material](gsagh-create-material-component.html) |Create a [Material](gsagh-material-parameter.html) for a  Section, Prop2d or Prop3d |
|![Edit Material](./images/EditMaterial.png) |[Edit Material](gsagh-edit-material-component.html) |Modify a [Material](gsagh-material-parameter.html)  |
|![Material Properties](./images/MaterialProperties.png) |[Material Properties](gsagh-material-properties-component.html) |Get [Material](gsagh-material-parameter.html) Properties for Elastic Isotropic material type  |

#### Secondary

|<img width=20/>   |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- |
|![Create Profile](./images/CreateProfile.png) |[Create Profile](gsagh-create-profile-component.html) |Create Profile text-string for a [Section](gsagh-section-parameter.html)  |
|![Edit Profile](./images/EditProfile.png) |[Edit Profile](gsagh-edit-profile-component.html) |Transform a Profile by rotation or reflection. |
|![Profile Dimensions](./images/ProfileDimensions.png) |[Profile Dimensions](gsagh-profile-dimensions-component.html) |Get [Section](gsagh-section-parameter.html) Dimensions  |
|![Section Properties](./images/SectionProperties.png) |[Section Properties](gsagh-section-properties-component.html) |Get [Section](gsagh-section-parameter.html) Properties  |
|![Taper Profile](./images/TaperProfile.png) |[Taper Profile](gsagh-taper-profile-component.html) |Create a Profile that tapers along its length from start and end profiles |

#### Tertiary

|<img width=20/>   |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- |
|![Create Section](./images/CreateSection.png) |[Create Section](gsagh-create-section-component.html) |Create a [Section](gsagh-section-parameter.html)  |
|![Create Section Modifier](./images/CreateSectionModifier.png) |[Create Section Modifier](gsagh-create-section-modifier-component.html) |Create a [Section](gsagh-section-parameter.html) Modifier  |
|![Edit Section](./images/EditSection.png) |[Edit Section](gsagh-edit-section-component.html) |Modify [Section](gsagh-section-parameter.html)  |
|![Get Section Modifier](./images/GetSectionModifier.png) |[Get Section Modifier](gsagh-get-section-modifier-component.html) |Get [Section](gsagh-section-parameter.html) Modifier  |

#### Quarternary

|<img width=20/>   |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- |
|![Create 2D Property](./images/Create2DProperty.png) |[Create 2D Property](gsagh-create-2d-property-component.html) |Create a  Property 2D |
|![Create 2D Property Modifier](./images/Create2DPropertyModifier.png) |[Create 2D Property Modifier](gsagh-create-2d-property-modifier-component.html) |Create 2D Property Modifier |
|![Edit 2D Property](./images/Edit2DProperty.png) |[Edit 2D Property](gsagh-edit-2d-property-component.html) |Modify 2D Property |
|![Get 2D Property Modifier](./images/Get2DPropertyModifier.png) |[Get 2D Property Modifier](gsagh-get-2d-property-modifier-component.html) |Get 2D Property Modifier |

#### Quinary

|<img width=20/>   |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- |
|![Create 3D Property](./images/Create3DProperty.png) |[Create 3D Property](gsagh-create-3d-property-component.html) |Create  Property 3D |
|![Edit 3D Property](./images/Edit3DProperty.png) |[Edit 3D Property](gsagh-edit-3d-property-component.html) |Modify a Property 3D |

#### Senary

|<img width=20/>   |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- |
|![Create Offset](./images/CreateOffset.png) |[Create Offset](gsagh-create-offset-component.html) |Create an [Offset](gsagh-offset-parameter.html)  |
|![Edit Offset](./images/EditOffset.png) |[Edit Offset](gsagh-edit-offset-component.html) |Modify [Offset](gsagh-offset-parameter.html) or just get information about existing  |

#### Septenary

|<img width=20/>   |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- |
|![Create Bool6](./images/CreateBool6.png) |[Create Bool6](gsagh-create-bool6-component.html) |Create a [Bool6](gsagh-bool6-parameter.html) containing six booleans representing a release or restriant.  |
|![Edit Bool6](./images/EditBool6.png) |[Edit Bool6](gsagh-edit-bool6-component.html) |Modify a [Bool6](gsagh-bool6-parameter.html) or just get information about existing  |


