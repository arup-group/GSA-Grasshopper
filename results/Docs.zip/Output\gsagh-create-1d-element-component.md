# Create 1D Element
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided "as-is" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

|<img width=150/> Icon |
| ----------- |
|![Create 1D Element](./images/Create1DElement.png) |

## Description

Create GSA 1D Element

_Note: This component can preview 3D Sections, right-click the middle of the component to toggle the section preview._

### Input parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![LineParam](./images/LineParam.png) |`Line` |**Line** |Line to create Element |
|![SectionParam](./images/SectionParam.png) |[Section](gsagh-section-parameter.html) |**Section** |Section Property (Beam) parameter |

### Output parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![Element1dParam](./images/Element1dParam.png) |[Element 1D](gsagh-element-1d-parameter.html) |**Element 1D** |GSA 1D Element parameter |


