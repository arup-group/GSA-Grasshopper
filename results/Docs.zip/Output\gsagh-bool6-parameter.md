# Bool6
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided "as-is" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

|<img width=150/> Icon |
| ----------- |
|![Bool6Param](./images/Bool6Param.png) |

::: tip Did you know?
The `Bool6` icon takes inspiration from the central pin/hinge/charnier connection [Ove Arup's Kingsgate footbridge](https://www.arup.com/projects/kingsgate-footbridge).
![Kingsgate Footbridge Durham](./images/Kingsgate-Footbridge-Durham.jpg)
*(c) Giles Rocholl / Arup*
:::

## Description

A Bool6 contains six booleans to set releases in [Element 1D](gsagh-element-1d-parameter.html)s and [Member 1D](gsagh-member-1d-parameter.html)s, or restraints in [Node](gsagh-node-parameter.html)s.

## Properties

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![BooleanParam](./images/BooleanParam.png) |`Boolean` |**X** |Release or restrain for translation in the X-direction. |
|![BooleanParam](./images/BooleanParam.png) |`Boolean` |**Y** |Release or restrain for translation in the Y-direction. |
|![BooleanParam](./images/BooleanParam.png) |`Boolean` |**Z** |Release or restrain for translation in the Z-direction. |
|![BooleanParam](./images/BooleanParam.png) |`Boolean` |**XX** |Release or restrain for rotation around the X-axis. |
|![BooleanParam](./images/BooleanParam.png) |`Boolean` |**YY** |Release or restrain for rotation around the Y-axis. |
|![BooleanParam](./images/BooleanParam.png) |`Boolean` |**ZZ** |Release or restrain for rotation around the Z-axis. |

_Note: the above properties can be retrieved using the [Edit Bool6](gsagh-edit-bool6-component.html) component_
