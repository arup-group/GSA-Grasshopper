# Analyse Model
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided "as-is" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

|<img width=150/> Icon |
| ----------- |
|![Analyse Model](./images/AnalyseModel.png) |

## Description

Assemble and Analyse a GSA Model

_Note: This is a dropdown component and input/output may vary depending on the selected dropdown_

### Input parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![GenericParam](./images/GenericParam.png) |`Generic` _List_ |**Model(s) and Lists** |Existing Model(s) to append to and Lists<br />If you input more than one model they will be merged<br />with first model in list taking priority for IDs |
|![GenericParam](./images/GenericParam.png) |`Generic` _List_ |**Properties** |Sections (PB), Prop2Ds (PA) and Prop3Ds (PV) to add/set in the model<br />Properties already added to Elements or Members<br />will automatically be added with Geometry input |
|![GenericParam](./images/GenericParam.png) |`Generic` _List_ |**GSA Geometry** |Nodes, Element1Ds, Element2Ds, Member1Ds, Member2Ds and Member3Ds to add/set in model |
|![GenericParam](./images/GenericParam.png) |`Generic` _List_ |**Load** |Loads to add to the model<br />You can also use this input to add Edited GridPlaneSurfaces |
|![GenericParam](./images/GenericParam.png) |`Generic` _List_ |**Analysis Tasks & Combinations** |Analysis Tasks and Combination Cases to add to the model |

### Output parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![ModelParam](./images/ModelParam.png) |[Model](gsagh-model-parameter.html) |**Model** |GSA Model parameter |
|![TextParam](./images/TextParam.png) |`Text` _List_ |**Report** |Analysis Task Report(s) |


