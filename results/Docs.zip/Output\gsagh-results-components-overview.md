# Results components 
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

#### Primary

|<img width=20/>   |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- |
|![Get Result](./images/GetResult.png) |[Get Result](gsagh-get-result-component.html) |Get AnalysisCase or Combination Result from an analysed [Model](gsagh-model-parameter.html)  |
|![Get Result Cases](./images/GetResultCases.png) |[Get Result Cases](gsagh-get-result-cases-component.html) |Get Analysis or Combination Case IDs from a [Model](gsagh-model-parameter.html) with Results  |
|![Select Result](./images/SelectResult.png) |[Select Result](gsagh-select-result-component.html) |Select AnalysisCase or Combination Result from an analysed [Model](gsagh-model-parameter.html)  |

#### Secondary

|<img width=20/>   |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- |
|![Node Displacements](./images/NodeDisplacements.png) |[Node Displacements](gsagh-node-displacements-component.html) |Node Translation and Rotation result values |
|![Reaction Forces](./images/ReactionForces.png) |[Reaction Forces](gsagh-reaction-forces-component.html) |Reaction Force result values |
|![Spring Reaction Forces](./images/SpringReactionForces.png) |[Spring Reaction Forces](gsagh-spring-reaction-forces-component.html) |Spring Reaction Force result values |

#### Tertiary

|<img width=20/>   |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- |
|![Beam Displacements](./images/BeamDisplacements.png) |[Beam Displacements](gsagh-beam-displacements-component.html) |Element1D Translation and Rotation result values |
|![Beam Forces and Moments](./images/BeamForcesandMoments.png) |[Beam Forces and Moments](gsagh-beam-forces-and-moments-component.html) |Element1D Force and Moment result values |
|![Beam Strain Energy Density](./images/BeamStrainEnergyDensity.png) |[Beam Strain Energy Density](gsagh-beam-strain-energy-density-component.html) |Element1D Strain Energy Density result values |

#### Quarternary

|<img width=20/>   |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- |
|![Element 2D Displacements](./images/Element2DDisplacements.png) |[Element 2D Displacements](gsagh-element-2d-displacements-component.html) |2D Translation and Rotation result values |
|![Element 2D Forces and Moments](./images/Element2DForcesandMoments.png) |[Element 2D Forces and Moments](gsagh-element-2d-forces-and-moments-component.html) |2D Projected Force and Moment result values |
|![Element 2D Stresses](./images/Element2DStresses.png) |[Element 2D Stresses](gsagh-element-2d-stresses-component.html) |2D Projected Stress result values |

#### Quinary

|<img width=20/>   |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- |
|![Element 3D Displacements](./images/Element3DDisplacements.png) |[Element 3D Displacements](gsagh-element-3d-displacements-component.html) |3D Translation and Rotation result values |
|![Element 3D Stresses](./images/Element3DStresses.png) |[Element 3D Stresses](gsagh-element-3d-stresses-component.html) |3D Element Stress result values |

#### Senary

|<img width=20/>   |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- |
|![Footfall Results](./images/FootfallResults.png) |[Footfall Results](gsagh-footfall-results-component.html) |Get the maximum response factor for a footfall analysis case |

#### Septenary

|<img width=20/>   |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- |
|![Global Performance Results](./images/GlobalPerformanceResults.png) |[Global Performance Results](gsagh-global-performance-results-component.html) |Get Global Performance (Dynamic, Model Stability, and Buckling) Results from a [Model](gsagh-model-parameter.html)  |
|![Total Loads and Reactions](./images/TotalLoadsandReactions.png) |[Total Loads and Reactions](gsagh-total-loads-and-reactions-component.html) |Get Total Loads and Reaction Results from a [Model](gsagh-model-parameter.html)  |


