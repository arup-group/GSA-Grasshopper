# Material
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided "as-is" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

|<img width=150/> Icon |
| ----------- |
|![MaterialParam](./images/MaterialParam.png) |

## Description

A Material is used by [Section](gsagh-section-parameter.html)s, [Property 2D](gsagh-property-2d-parameter.html)s and [Property 3D](gsagh-property-3d-parameter.html)s. It is only possible to work with elastic isotropic material types. A Material can either be created as a Standard Material from design code and grade using the [Create Material](gsagh-create-material-component.html) component, or as a custom material using the [Create Custom Material](gsagh-create-custom-material-component.html) component.

Use the [Get Model Materials](gsagh-get-model-materials-component.html) to get all materials in a [Model](gsagh-model-parameter.html) and then use [Edit Material](gsagh-edit-material-component.html) in combination with [Material Properties](gsagh-material-properties-component.html) to get information about material properties.

Refer to [Materials](/references/hidr-data-mat-steel.html) to read more.



## Properties

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![IntegerParam](./images/IntegerParam.png) |`Integer` |**Material ID** |the Material's ID in its respective table (Steel, Concrete, etc) |
|![TextParam](./images/TextParam.png) |`Text` |**Material Name** |the Material's Name |
|![MaterialParam](./images/MaterialParam.png) |[Material](gsagh-material-parameter.html) |**Custom Material** |A copy of this material as a Custom material. |
|![TextParam](./images/TextParam.png) |`Text` |**Material Type** |Material Type |

_Note: the above properties can be retrieved using the [Edit Material](gsagh-edit-material-component.html) component_
