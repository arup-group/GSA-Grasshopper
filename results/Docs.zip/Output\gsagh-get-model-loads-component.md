# Get Model Loads
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided "as-is" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

|<img width=150/> Icon |
| ----------- |
|![Get Model Loads](./images/GetModelLoads.png) |

## Description

Get Loads and Grid Planes/Surfaces from GSA model

_Note: This is a dropdown component and input/output may vary depending on the selected dropdown_

### Input parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![ModelParam](./images/ModelParam.png) |[Model](gsagh-model-parameter.html) |**GSA Model** |model containing some loads |

### Output parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![LoadCaseParam](./images/LoadCaseParam.png) |[Load Case](gsagh-load-case-parameter.html) _List_ |**Load Cases** |Load Cases from GSA Model |
|![LoadParam](./images/LoadParam.png) |[Load](gsagh-load-parameter.html) _List_ |**Gravity Loads** |Gravity Loads from GSA Model |
|![LoadParam](./images/LoadParam.png) |[Load](gsagh-load-parameter.html) _List_ |**Node Loads** |Node Loads from GSA Model |
|![LoadParam](./images/LoadParam.png) |[Load](gsagh-load-parameter.html) _List_ |**Beam Loads** |Beam Loads from GSA Model |
|![LoadParam](./images/LoadParam.png) |[Load](gsagh-load-parameter.html) _List_ |**Grid Point Loads [m]** |Face Loads from GSA Model |
|![LoadParam](./images/LoadParam.png) |[Load](gsagh-load-parameter.html) _List_ |**Grid Line Loads [m]** |Grid Point Loads from GSA Model |
|![LoadParam](./images/LoadParam.png) |[Load](gsagh-load-parameter.html) _List_ |**Grid Area Loads [m]** |Grid Line Loads from GSA Model |
|![LoadParam](./images/LoadParam.png) |[Load](gsagh-load-parameter.html) _List_ |**Grid Plane Surfaces [m]** |Grid Area Loads from GSA Model |
|![GridPlaneSurfaceParam](./images/GridPlaneSurfaceParam.png) |[Grid Plane Surface](gsagh-grid-plane-surface-parameter.html) _List_ |**Grid Plane Surfaces [m]** |Grid Plane Surfaces from GSA Model |


