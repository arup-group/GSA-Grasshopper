# Create Custom Material
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided "as-is" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

|<img width=150/> Icon |
| ----------- |
|![Create Custom Material](./images/CreateCustomMaterial.png) |

## Description

Create a Custom GSA Analysis Material

_Note: This is a dropdown component and input/output may vary depending on the selected dropdown_

### Input parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![IntegerParam](./images/IntegerParam.png) |`Integer` |**Analysis Property Number** |Analysis Property Number (do not use 0 -> 'from Grade') |
|![TextParam](./images/TextParam.png) |`Text` |**Material Name** |Material Name of Custom Material |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Pressure ` |**Elastic Modulus [MPa]** |Elastic Modulus of the elastic isotropic material |
|![NumberParam](./images/NumberParam.png) |`Number` |**Poisson's Ratio** |Poisson's Ratio of the elastic isotropic material |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Density ` |**Density [kg/m³]** |Density of the elastic isotropic material |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Thermal Expansion ` |**Thermal Expansion [/°C]** |Thermal Expansion Coefficient of the elastic isotropic material |

### Output parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![MaterialParam](./images/MaterialParam.png) |[Material](gsagh-material-parameter.html) |**Material** |GSA Custom Material |


