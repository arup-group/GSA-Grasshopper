# Analysis components 
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

#### Primary

|<img width=20/>   |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- |
|![Analyse Model](./images/AnalyseModel.png) |[Analyse Model](gsagh-analyse-model-component.html) |Assemble and Analyse a [Model](gsagh-model-parameter.html)  |

#### Secondary

|<img width=20/>   |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- |
|![Create Analysis Task](./images/CreateAnalysisTask.png) |[Create Analysis Task](gsagh-create-analysis-task-component.html) |Create a Analysis Task |
|![Edit Analysis Task](./images/EditAnalysisTask.png) |[Edit Analysis Task](gsagh-edit-analysis-task-component.html) |Modify Analysis Tasks |

#### Tertiary

|<img width=20/>   |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- |
|![Combination Case Info](./images/CombinationCaseInfo.png) |[Combination Case Info](gsagh-combination-case-info-component.html) |Get information of a Combination Case |
|![Create Analysis Case](./images/CreateAnalysisCase.png) |[Create Analysis Case](gsagh-create-analysis-case-component.html) |Create a Analysis Case |
|![Create Combination Case](./images/CreateCombinationCase.png) |[Create Combination Case](gsagh-create-combination-case-component.html) |Create a new Combination Case |

#### Quarternary

|<img width=20/>   |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- |
|![Analysis Case Info](./images/AnalysisCaseInfo.png) |[Analysis Case Info](gsagh-analysis-case-info-component.html) |Get information about the properties of a Analysis Case (Load Case or Combination) |


