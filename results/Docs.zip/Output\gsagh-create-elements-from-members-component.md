# Create Elements from Members
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided "as-is" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

|<img width=150/> Icon |
| ----------- |
|![Create Elements from Members](./images/CreateElementsfromMembers.png) |

## Description

Create Elements from Members

_Note: This is a dropdown component and input/output may vary depending on the selected dropdown_

### Input parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![NodeParam](./images/NodeParam.png) |[Node](gsagh-node-parameter.html) _List_ |**Nodes [m]** |Nodes to be included in meshing |
|![Member1dParam](./images/Member1dParam.png) |[Member 1D](gsagh-member-1d-parameter.html) _List_ |**1D Members [m]** |1D Members to create 1D Elements from |
|![Member2dParam](./images/Member2dParam.png) |[Member 2D](gsagh-member-2d-parameter.html) _List_ |**2D Members [m]** |2D Members to create 2D Elements from |
|![Member3dParam](./images/Member3dParam.png) |[Member 3D](gsagh-member-3d-parameter.html) _List_ |**3D Members [m]** |3D Members to create 3D Elements from |

### Output parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![NodeParam](./images/NodeParam.png) |[Node](gsagh-node-parameter.html) _List_ |**Nodes** |GSA Nodes |
|![Element1dParam](./images/Element1dParam.png) |[Element 1D](gsagh-element-1d-parameter.html) _List_ |**1D Elements** |GSA 1D Elements |
|![Element2dParam](./images/Element2dParam.png) |[Element 2D](gsagh-element-2d-parameter.html) _List_ |**2D Elements** |GSA 2D Elements |
|![Element3dParam](./images/Element3dParam.png) |[Element 3D](gsagh-element-3d-parameter.html) _List_ |**3D Elements** |GSA 3D Elements |
|![ModelParam](./images/ModelParam.png) |[Model](gsagh-model-parameter.html) |**GSA Model** |GSA Model with Elements and Members |


