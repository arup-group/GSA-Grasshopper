# Geometry components 
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

#### Primary

|<img width=20/>   |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- |
|![Create Support](./images/CreateSupport.png) |[Create Support](gsagh-create-support-component.html) |Create [Node](gsagh-node-parameter.html) Support  |
|![Edit Node](./images/EditNode.png) |[Edit Node](gsagh-edit-node-component.html) |Modify [Node](gsagh-node-parameter.html)  |

#### Secondary

|<img width=20/>   |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- |
|![Create 1D Element](./images/Create1DElement.png) |[Create 1D Element](gsagh-create-1d-element-component.html) |Create 1D Element |
|![Create 2D Element](./images/Create2DElement.png) |[Create 2D Element](gsagh-create-2d-element-component.html) |Create 2D Element |
|![Edit 1D Element](./images/Edit1DElement.png) |[Edit 1D Element](gsagh-edit-1d-element-component.html) |Modify 1D Element |
|![Edit 2D Element](./images/Edit2DElement.png) |[Edit 2D Element](gsagh-edit-2d-element-component.html) |Modify 2D Element |
|![Edit 3D Element](./images/Edit3DElement.png) |[Edit 3D Element](gsagh-edit-3d-element-component.html) |Modify 3D Element |

#### Tertiary

|<img width=20/>   |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- |
|![Create 1D Member](./images/Create1DMember.png) |[Create 1D Member](gsagh-create-1d-member-component.html) |Create 1D Member |
|![Create 2D Member](./images/Create2DMember.png) |[Create 2D Member](gsagh-create-2d-member-component.html) |Create Member 2D |
|![Create 3D Member](./images/Create3DMember.png) |[Create 3D Member](gsagh-create-3d-member-component.html) |Create Member 3D |
|![Edit 1D Member](./images/Edit1DMember.png) |[Edit 1D Member](gsagh-edit-1d-member-component.html) |Modify 1D Member |
|![Edit 2D Member](./images/Edit2DMember.png) |[Edit 2D Member](gsagh-edit-2d-member-component.html) |Modify 2D Member |
|![Edit 3D Member](./images/Edit3DMember.png) |[Edit 3D Member](gsagh-edit-3d-member-component.html) |Modify 3D Member |

#### Quarternary

|<img width=20/>   |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- |
|![Create 2D Elements from Brep](./images/Create2DElementsfromBrep.png) |[Create 2D Elements from Brep](gsagh-create-2d-elements-from-brep-component.html) |Mesh a non-planar Brep |
|![Create Elements from Members](./images/CreateElementsfromMembers.png) |[Create Elements from Members](gsagh-create-elements-from-members-component.html) |Create Elements from Members |

#### Quinary

|<img width=20/>   |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- |
|![Local Axes](./images/LocalAxes.png) |[Local Axes](gsagh-local-axes-component.html) |Get the local axes from a 1D Element or Member |
|![Section Alignment](./images/SectionAlignment.png) |[Section Alignment](gsagh-section-alignment-component.html) |Automatically create Offset based on desired Alignment and Section profile |

#### Septenary

|<img width=20/>   |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- |
|![Create Buckling Factors](./images/CreateBucklingFactors.png) |[Create Buckling Factors](gsagh-create-buckling-factors-component.html) |Create a Equivalent uniform moment factor for LTB for 1D Member |
|![Edit Buckling Factors](./images/EditBucklingFactors.png) |[Edit Buckling Factors](gsagh-edit-buckling-factors-component.html) |Modify Equivalent uniform moment factor for LTB for 1D Member |


