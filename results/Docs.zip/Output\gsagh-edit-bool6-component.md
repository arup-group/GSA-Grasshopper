# Edit Bool6
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided "as-is" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

|<img width=150/> Icon |
| ----------- |
|![Edit Bool6](./images/EditBool6.png) |

## Description

Modify a GSA Bool6 or just get information about existing

### Input parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![Bool6Param](./images/Bool6Param.png) |[Bool6](gsagh-bool6-parameter.html) |**Bool6** |Bool6 containing six booleans representing a release or restriant. to get or set information for. Leave blank to create a new Bool6 |
|![BooleanParam](./images/BooleanParam.png) |`Boolean` |**X** |Release or restrain for translation in the X-direction. |
|![BooleanParam](./images/BooleanParam.png) |`Boolean` |**Y** |Release or restrain for translation in the Y-direction. |
|![BooleanParam](./images/BooleanParam.png) |`Boolean` |**Z** |Release or restrain for translation in the Z-direction. |
|![BooleanParam](./images/BooleanParam.png) |`Boolean` |**XX** |Release or restrain for rotation around the X-axis. |
|![BooleanParam](./images/BooleanParam.png) |`Boolean` |**YY** |Release or restrain for rotation around the Y-axis. |
|![BooleanParam](./images/BooleanParam.png) |`Boolean` |**ZZ** |Release or restrain for rotation around the Z-axis. |

### Output parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![Bool6Param](./images/Bool6Param.png) |[Bool6](gsagh-bool6-parameter.html) |**Bool6** |GSA Bool6 containing six booleans representing a release or restriant. with applied changes. |
|![BooleanParam](./images/BooleanParam.png) |`Boolean` |**X** |Release or restrain for translation in the X-direction. |
|![BooleanParam](./images/BooleanParam.png) |`Boolean` |**Y** |Release or restrain for translation in the Y-direction. |
|![BooleanParam](./images/BooleanParam.png) |`Boolean` |**Z** |Release or restrain for translation in the Z-direction. |
|![BooleanParam](./images/BooleanParam.png) |`Boolean` |**XX** |Release or restrain for rotation around the X-axis. |
|![BooleanParam](./images/BooleanParam.png) |`Boolean` |**YY** |Release or restrain for rotation around the Y-axis. |
|![BooleanParam](./images/BooleanParam.png) |`Boolean` |**ZZ** |Release or restrain for rotation around the Z-axis. |


