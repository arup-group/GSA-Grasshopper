# Get Model Analysis
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided "as-is" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

|<img width=150/> Icon |
| ----------- |
|![Get Model Analysis](./images/GetModelAnalysis.png) |

## Description

Get Analysis Tasks and their Cases from GSA model

### Input parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![ModelParam](./images/ModelParam.png) |[Model](gsagh-model-parameter.html) |**GSA Model** |model containing some Analysis Cases, Combinations and Tasks |

### Output parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![AnalysisTaskParam](./images/AnalysisTaskParam.png) |[Analysis Task](gsagh-analysis-task-parameter.html) _List_ |**Analysis Tasks** |List of Analysis Tasks in model |
|![AnalysisCaseParam](./images/AnalysisCaseParam.png) |[Analysis Case](gsagh-analysis-case-parameter.html) _List_ |**Analysis Cases** |List of Analysis Cases in model |
|![CombinationCaseParam](./images/CombinationCaseParam.png) |[Combination Case](gsagh-combination-case-parameter.html) _List_ |**Combination Cases** |List of Combination Cases in model |


