# Create Offset
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided "as-is" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

|<img width=150/> Icon |
| ----------- |
|![Create Offset](./images/CreateOffset.png) |

## Description

Create an GSA Offset

_Note: This is a dropdown component and input/output may vary depending on the selected dropdown_

### Input parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` |**Offset X1 [m]** |X1 - Start axial offset |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` |**Offset X2 [m]** |X2 - End axial offset |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` |**Offset Y [m]** |Y Offset |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` |**Offset Z [m]** |Z Offset |

### Output parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![OffsetParam](./images/OffsetParam.png) |[Offset](gsagh-offset-parameter.html) |**Offset** |GSA Offset parameter |


