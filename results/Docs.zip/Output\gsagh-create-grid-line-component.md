# Create Grid Line
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided "as-is" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

|<img width=150/> Icon |
| ----------- |
|![Create Grid Line](./images/CreateGridLine.png) |

## Description

Create a GSA Grid Line from a line or arc.

### Input parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![CurveParam](./images/CurveParam.png) |`Curve` |**Curve** |Straight line or circular arc to create a Grid Line |
|![TextParam](./images/TextParam.png) |`Text` |**Label** |The name by which the grid line is referred |
|![NumberParam](./images/NumberParam.png) |`Number` |**Pattern** |Pattern |

### Output parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![GridLineParam](./images/GridLineParam.png) |[Grid Line](gsagh-grid-line-parameter.html) |**Grid Line** |GSA Grid Line parameter |


