# Edit Analysis Task
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided "as-is" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

|<img width=150/> Icon |
| ----------- |
|![Edit Analysis Task](./images/EditAnalysisTask.png) |

## Description

Modify GSA Analysis Tasks

### Input parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![AnalysisTaskParam](./images/AnalysisTaskParam.png) |[Analysis Task](gsagh-analysis-task-parameter.html) |**Analysis Task** |Analysis Task to Edit |
|![AnalysisCaseParam](./images/AnalysisCaseParam.png) |[Analysis Case](gsagh-analysis-case-parameter.html) _List_ |**Analysis Case(s)** |Add list of Analysis Case to task |

### Output parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![AnalysisTaskParam](./images/AnalysisTaskParam.png) |[Analysis Task](gsagh-analysis-task-parameter.html) |**Analysis Task** |Modified Analysis Task |
|![TextParam](./images/TextParam.png) |`Text` |**Name** |Task Name |
|![AnalysisCaseParam](./images/AnalysisCaseParam.png) |[Analysis Case](gsagh-analysis-case-parameter.html) _List_ |**Analysis Case(s)** |List of GSA Analysis Case |
|![TextParam](./images/TextParam.png) |`Text` |**Solver Type** |Solver Type |
|![IntegerParam](./images/IntegerParam.png) |`Integer` |**TaskID** |The Task number if the Analysis Case ever belonged to a model |


