# Buckling Factors
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided "as-is" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

|<img width=150/> Icon |
| ----------- |
|![BucklingFactorsParam](./images/BucklingFactorsParam.png) |

## Description

Buckling Factors are part of a [Member 1D](gsagh-member-1d-parameter.html) and can be used to override the automatically calculated factors that accounts for the shape of the moment diagram in lateral torsional buckling design equations. This override is applied for all bending segments in the member. Refer to [Equivalent uniform moment factor for LTB](/references/hidd-page-member-steel.html#equivalent-uniform-moment-factor-for-ltb) to read more.



## Properties

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![NumberParam](./images/NumberParam.png) |`Number` |**Factor Lsy** |Moment Amplification Factor, Strong Axis |
|![NumberParam](./images/NumberParam.png) |`Number` |**Factor Lsz** |Moment Amplification Factor, Weak Axis |
|![NumberParam](./images/NumberParam.png) |`Number` |**Equivalent uniform moment factor for LTB** |Override the automatically calculated factor to account for the shape of the moment diagram in lateral torsional buckling design equations. This override is applied for all bending segments in the member.  This override is applied to the following variable for each design code:<br /> AISC 360: C_b <br /> AS 4100: alpha_m <br /> BS 5950: m_LT <br /> CSA S16: omega_2 <br /> EN 1993-1-1 and EN 1993-1-2: C_1 <br /> Hong Kong Code of Practice: m_LT <br /> IS 800: C_mLT <br /> SANS 10162-1: omega_2 |

_Note: the above properties can be retrieved using the [Edit Buckling Factors](gsagh-edit-buckling-factors-component.html) component_
