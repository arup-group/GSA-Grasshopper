# Profile Dimensions
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided "as-is" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

|<img width=150/> Icon |
| ----------- |
|![Profile Dimensions](./images/ProfileDimensions.png) |

## Description

Get GSA Section Dimensions

### Input parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![SectionParam](./images/SectionParam.png) |[Section](gsagh-section-parameter.html) |**Section** |Section Property (Beam) to get a bit more info out of. |

### Output parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` |**Depth [cm]** |Section Depth or Diameter) |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` |**Width [cm]** |Section Width |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` |**Width Top [cm]** |Section Width Top (will be equal to width if profile is symmetric) |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` |**Width Bottom [cm]** |Section Width Bottom (will be equal to width if profile is symmetric) |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` |**Flange Thk Top [cm]** |Section Top Flange Thickness |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` |**Flange Thk Bottom [cm]** |Section Bottom Flange Thickness |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` |**Web Thk [cm]** |Section Web Thickness |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` |**Radius [cm]** |Section Root Radius (only applicable to catalogue profiles) or hole size for cellular/castellated beams |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` |**Spacing [cm]** |Spacing/pitch |
|![TextParam](./images/TextParam.png) |`Text` |**Type** |Profile type description |


