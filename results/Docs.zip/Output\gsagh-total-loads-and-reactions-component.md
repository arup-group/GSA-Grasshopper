# Total Loads and Reactions
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided "as-is" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

|<img width=150/> Icon |
| ----------- |
|![Total Loads and Reactions](./images/TotalLoadsandReactions.png) |

## Description

Get Total Loads and Reaction Results from a GSA model

_Note: This is a dropdown component and input/output may vary depending on the selected dropdown_

### Input parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![ResultParam](./images/ResultParam.png) |[Result](gsagh-result-parameter.html) |**Result** |Result |

### Output parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Force ` |**Force X [kN]** |Sum of all Force Loads in GSA Model in X-direction |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Force ` |**Force Y [kN]** |Sum of all Force Loads in GSA Model in Y-direction |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Force ` |**Force Z [kN]** |Sum of all Force Loads in GSA Model in Z-direction |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Force ` |**Force XYZ [kN]** |Sum of all Force Loads in GSA Model |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Moment ` |**Moment XX [kN·m]** |Sum of all Moment Loads in GSA Model around X-axis |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Moment ` |**Moment YY [kN·m]** |Sum of all Moment Loads in GSA Model around Y-axis |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Moment ` |**Moment ZZ [kN·m]** |Sum of all Moment Loads in GSA Model around Z-axis |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Moment ` |**Moment XXYYZZ [kN·m]** |Sum of all Moment Loads in GSA Model |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Force ` |**Total Reaction X [kN]** |Sum of all Reaction Forces in GSA Model in X-direction |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Force ` |**Total Reaction Y [kN]** |Sum of all Reaction Forces in GSA Model in Y-direction |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Force ` |**Total Reaction Z [kN]** |Sum of all Reaction Forces in GSA Model in Z-direction |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Force ` |**Total Reaction XYZ [kN]** |Sum of all Reaction Forces in GSA Model |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Moment ` |**Total Reaction XX [kN·m]** |Sum of all Reaction Moments in GSA Model around X-axis |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Moment ` |**Total Reaction XX  [kN·m]** |Sum of all Reaction Moments in GSA Model around Y-axis |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Moment ` |**Total Reaction XX  [kN·m]** |Sum of all Reaction Moments in GSA Model around Z-axis |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Moment ` |**Total Reaction XXYYZZ  [kN·m]** |Sum of all Reaction Moments in GSA Model |


