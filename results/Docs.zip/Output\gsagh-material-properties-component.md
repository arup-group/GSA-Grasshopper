# Material Properties
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided "as-is" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

|<img width=150/> Icon |
| ----------- |
|![Material Properties](./images/MaterialProperties.png) |

## Description

Get GSA Material Properties for Elastic Isotropic material type

### Input parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![MaterialParam](./images/MaterialParam.png) |[Material](gsagh-material-parameter.html) |**Material** |Custom Material |

### Output parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Pressure ` |**Elastic Modulus [MPa]** |Elastic Modulus of the elastic isotropic material |
|![NumberParam](./images/NumberParam.png) |`Number` |**Poisson's Ratio** |Poisson's Ratio of the elastic isotropic material |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Density ` |**Density [kg/m³]** |Density of the elastic isotropic material |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Coefficient Of Thermal Expansion ` |**Thermal Expansion [°C⁻¹]** |Thermal Expansion Coefficient of the elastic isotropic material |


