# Global Performance Results
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided "as-is" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

|<img width=150/> Icon |
| ----------- |
|![Global Performance Results](./images/GlobalPerformanceResults.png) |

## Description

Get Global Performance (Dynamic, Model Stability, and Buckling) Results from a GSA model

_Note: This is a dropdown component and input/output may vary depending on the selected dropdown_

### Input parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![ResultParam](./images/ResultParam.png) |[Result](gsagh-result-parameter.html) |**Result** |Result |

### Output parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Magnetic Field ` |**Effective Mass X [t]** |Effective Mass in GSA Model in X-direction |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Magnetic Field ` |**Effective Mass Y [t]** |Effective Mass in GSA Model in Y-direction |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Magnetic Field ` |**Effective Mass Z [t]** |Effective Mass in GSA Model in Z-direction |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Magnetic Field ` |**Effective Mass XYZ [t]** |Effective Mass in GSA Model |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Area Moment Of Inertia ` |**Effective Inertia X [m⁴]** |Effective Inertia in GSA Model in X-direction |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Area Moment Of Inertia ` |**Effective Inertia Y [m⁴]** |Effective Inertia in GSA Model in Y-direction |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Area Moment Of Inertia ` |**Effective Inertia Z [m⁴]** |Effective Inertia in GSA Model in Z-direction |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Area Moment Of Inertia ` |**Effective Inertia XYZ [m⁴]** |Effective Inertia in GSA Model |
|![NumberParam](./images/NumberParam.png) |`Number` |**Mode** |Mode number if LC is a dynamic task |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Magnetic Field ` |**Modal Mass [t]** |Modal Mass of selected LoadCase / mode |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Force Per Length ` |**Modal Stiffness [kN/m]** |Modal Stiffness of selected LoadCase / mode |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Force Per Length ` |**Modal Geometric Stiffness [kN/m]** |Modal Geometric Stiffness of selected LoadCase / mode |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Frequency ` |**Frequency [Hz]** |Frequency of selected LoadCase / mode |
|![NumberParam](./images/NumberParam.png) |`Number` |**Load Factor** |Load Factor for selected LoadCase / mode |
|![NumberParam](./images/NumberParam.png) |`Number` |**Eigenvalue** |Eigenvalue for selected LoadCase / mode |


