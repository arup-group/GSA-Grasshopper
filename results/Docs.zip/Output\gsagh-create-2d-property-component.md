# Create 2D Property
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided "as-is" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

|<img width=150/> Icon |
| ----------- |
|![Create 2D Property](./images/Create2DProperty.png) |

## Description

Create a GSA  Property 2D

_Note: This is a dropdown component and input/output may vary depending on the selected dropdown_

### Input parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` |**Thickness [cm]** |Section thickness |
|![MaterialParam](./images/MaterialParam.png) |[Material](gsagh-material-parameter.html) |**Material** |Material |
|![GenericParam](./images/GenericParam.png) |`Generic` |**Reference Surface** |Reference Surface Middle = 0 (default), Top = 1, Bottom = 2 |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Length ` |**Offset [cm]** |Additional Offset |

### Output parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![Property2dParam](./images/Property2dParam.png) |[Property 2D](gsagh-property-2d-parameter.html) |**Property 2D** |GSA 2D Property (Area) parameter |


