# Reaction Forces
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided "as-is" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

|<img width=150/> Icon |
| ----------- |
|![Reaction Forces](./images/ReactionForces.png) |

## Description

Reaction Force result values

_Note: This is a dropdown component and input/output may vary depending on the selected dropdown_

### Input parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![ResultParam](./images/ResultParam.png) |[Result](gsagh-result-parameter.html) _List_ |**Result** |Result |
|![ListParam](./images/ListParam.png) |[List](gsagh-list-parameter.html) |**Node filter list** |Filter the Nodes by list. (by default 'all')<br />Node list should take the form:<br /> 1 11 to 72 step 2 not (XY3 31 to 45)<br />Refer to help file for definition of lists and full vocabulary. |

### Output parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Force ` _Tree_ |**Force X [kN]** |Reaction Forces in Global X-direction in Global Axis. |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Force ` _Tree_ |**Force Y [kN]** |Reaction Forces in Global Y-direction in Global Axis. |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Force ` _Tree_ |**Force Z [kN]** |Reaction Forces in Global Z-direction in Global Axis. |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Force ` _Tree_ |**Force XYZ [kN]** |Combined XYZ Reaction Forces in Global Axis. |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Moment ` _Tree_ |**Moment XX [kN·m]** |Reaction Moments around Global X-axis in Global Axis. |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Moment ` _Tree_ |**Moment YY [kN·m]** |Reaction Moments around Global Y-axis in Global Axis. |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Moment ` _Tree_ |**Moment ZZ [kN·m]** |Reaction Moments around Global Z-axis in Global Axis. |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Moment ` _Tree_ |**Moment XXYYZZ [kN·m]** |Combined XXYYZZ Reaction Moments in Global Axis. |
|![TextParam](./images/TextParam.png) |`Text` _List_ |**Nodes IDs** |Node IDs for each result value |


