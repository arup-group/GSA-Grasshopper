# Create Beam Load
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided "as-is" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

|<img width=150/> Icon |
| ----------- |
|![Create Beam Load](./images/CreateBeamLoad.png) |

## Description

Create GSA Beam Load

_Note: This is a dropdown component and input/output may vary depending on the selected dropdown_

### Input parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![LoadCaseParam](./images/LoadCaseParam.png) |[Load Case](gsagh-load-case-parameter.html) |**Load Case** |Load Case parameter |
|![GenericParam](./images/GenericParam.png) |`Generic` |**Loadable 1D Objects** |List, Custom Material, Section, 1D Elements or 1D Members to apply load to; either input Section, Element1d, or Member1d, or a text string.<br />Text string with Element list should take the form:<br /> 1 11 to 20 step 2 P1 not (G1 to G6 step 3) P11 not (PA PB1 PS2 PM3 PA4 M1)<br />Refer to help file for definition of lists and full vocabulary. |
|![TextParam](./images/TextParam.png) |`Text` |**Name** |Load Name |
|![IntegerParam](./images/IntegerParam.png) |`Integer` |**Axis** |Load axis (default Global). <br />Accepted inputs are:<br />0 : Global<br />-1 : Local |
|![TextParam](./images/TextParam.png) |`Text` |**Direction** |Load direction (default z).<br />Accepted inputs are:<br />x<br />y<br />z<br />xx<br />yy<br />zz |
|![BooleanParam](./images/BooleanParam.png) |`Boolean` |**Projected** |Projected (default not) |
|![NumberParam](./images/NumberParam.png) |`Number` |**Value [kN/m]** |Load Value |

### Output parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![LoadParam](./images/LoadParam.png) |[Load](gsagh-load-parameter.html) |**Beam Load** |GSA Beam Load |


