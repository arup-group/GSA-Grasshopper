# Edit Material
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided "as-is" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

|<img width=150/> Icon |
| ----------- |
|![Edit Material](./images/EditMaterial.png) |

## Description

Modify a GSA Material

### Input parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![MaterialParam](./images/MaterialParam.png) |[Material](gsagh-material-parameter.html) |**Material** |Material to get or set information for. Leave blank to create a new Material |
|![IntegerParam](./images/IntegerParam.png) |`Integer` |**Material ID** |(Optional) Set Material ID corrosponding to the desired ID in the material type's table (Steel, Concrete, etc). |
|![TextParam](./images/TextParam.png) |`Text` |**Material Name** |(Optional) Set Material Name |
|![MaterialParam](./images/MaterialParam.png) |[Material](gsagh-material-parameter.html) |**Analysis Material** |Material(Optional) Input another Material to overwrite the analysis material properties.Material |
|![GenericParam](./images/GenericParam.png) |`Generic` |**Material Type** |(Optional) Set Material Type for a Custom Material (only).<br />Input either text string or integer:<br />Generic : 0<br />Steel : 1<br />Concrete : 2<br />Aluminium : 3<br />Glass : 4<br />FRP : 5<br />Timber : 7<br />Fabric : 8 |

### Output parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![MaterialParam](./images/MaterialParam.png) |[Material](gsagh-material-parameter.html) |**Material** |GSA Material with applied changes. |
|![IntegerParam](./images/IntegerParam.png) |`Integer` |**Material ID** |the Material's ID in its respective table (Steel, Concrete, etc) |
|![TextParam](./images/TextParam.png) |`Text` |**Material Name** |the Material's Name |
|![MaterialParam](./images/MaterialParam.png) |[Material](gsagh-material-parameter.html) |**Custom Material** |A copy of this material as a Custom material. |
|![TextParam](./images/TextParam.png) |`Text` |**Material Type** |Material Type |


