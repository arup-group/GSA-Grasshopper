# Node
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided "as-is" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

|<img width=150/> Icon |
| ----------- |
|![NodeParam](./images/NodeParam.png) |

## Description

This class provides a parameter interface for the [List Goo](gsagh-list-goo-parameter.html) type.

## Properties

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![IntegerParam](./images/IntegerParam.png) |`Integer` |**Node number** |Original Node number (ID) if Node ever belonged to a GSA Model |
|![PointParam](./images/PointParam.png) |`Point` |**Node Position** |Position (x, y, z) of Node. Setting a new position will clear any existing ID |
|![PlaneParam](./images/PlaneParam.png) |`Plane` |**Node local axis** |Local axis (Plane) of Node |
|![Bool6Param](./images/Bool6Param.png) |[Bool6](gsagh-bool6-parameter.html) |**Node Restraints** |Restraints (Bool6) of Node |
|![IntegerParam](./images/IntegerParam.png) |`Integer` |**Damper Property** |Damper Property reference |
|![IntegerParam](./images/IntegerParam.png) |`Integer` |**Mass Property** |Mass Property reference |
|![IntegerParam](./images/IntegerParam.png) |`Integer` |**Spring Property** |Spring Property reference |
|![TextParam](./images/TextParam.png) |`Text` |**Node Name** |Name of Node |
|![ColourParam](./images/ColourParam.png) |`Colour` |**Node Colour** |colour of node |

_Note: the above properties can be retrieved using the [Edit Node](gsagh-edit-node-component.html) component_
