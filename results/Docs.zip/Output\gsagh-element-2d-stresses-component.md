# Element 2D Stresses
<!--- This file has been auto-generated, do not change it manually! Edit the generator here: https://github.com/arup-group/GSA-Grasshopper/tree/main/DocsGeneration --->

::: warning
GSA-Grasshopper plugin [GsaGH] is pre-release and under active development, including further testing to be undertaken. It is provided "as-is" and you bear the risk of using it. Future versions may contain breaking changes. Any files, results, or other types of output information created using GsaGH should not be relied upon without thorough and independent checking.
:::

|<img width=150/> Icon |
| ----------- |
|![Element 2D Stresses](./images/Element2DStresses.png) |

## Description

2D Projected Stress result values

_Note: This is a dropdown component and input/output may vary depending on the selected dropdown_

### Input parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![ResultParam](./images/ResultParam.png) |[Result](gsagh-result-parameter.html) _List_ |**Result** |Result |
|![ListParam](./images/ListParam.png) |[List](gsagh-list-parameter.html) |**Element filter list** |Filter the Elements by list. (by default 'all')<br />Element list should take the form:<br /> 1 11 to 20 step 2 P1 not (G1 to G6 step 3) P11 not (PA PB1 PS2 PM3 PA4 M1)<br />Refer to help file for definition of lists and full vocabulary. |
|![NumberParam](./images/NumberParam.png) |`Number` |**Stress Layer** |Layer within the cross-section to get results.<br />Input a number between -1 and 1, representing the normalised thickness,<br />default value is zero => middle of the element. |



_Output note: DataTree organised as { `CaseID` ; `Permutation` ; `ElementID` } fx. `{1;2;3}` is Case 1, Permutation 2, Element 3, where each branch contains a list of results in the following order: `Vertex(1)`, `Vertex(2)`, ..., `Vertex(i)`, `Centre` +ve in-plane stresses: tensile(ie. + ve direct strain). +ve bending stress gives rise to tension on the top surface. +ve shear stresses: +ve shear strain._
### Output parameters

|<img width=20/> Icon |<img width=200/> Type |<img width=200/> Name |<img width=1000/> Description |
| ----------- | ----------- | ----------- | ----------- |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Pressure ` _Tree_ |**Stress XX [MPa]** |Stress in XX-direction in Global Axis. |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Pressure ` _Tree_ |**Stress YY [MPa]** |Stress in YY-direction in Global Axis. |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Pressure ` _Tree_ |**Stress ZZ [MPa]** |Stress in ZZ-direction in Global Axis. |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Pressure ` _Tree_ |**Stress XY [MPa]** |Stress in XY-direction in Global Axis. |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Pressure ` _Tree_ |**Stress YZ [MPa]** |Stress in YZ-direction in Global Axis. |
|![UnitNumber](./images/UnitParam.png) |Unit Number  ` Pressure ` _Tree_ |**Stress ZX [MPa]** |Stress in ZX-direction in Global Axis. |


